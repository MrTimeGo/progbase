﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;

namespace Practice6
{
    class Program
    {
        static void Main(string[] args)
        {
            TaskA.Run();
            TaskB.Run();
            TaskC.Run();
        }
    }
}
